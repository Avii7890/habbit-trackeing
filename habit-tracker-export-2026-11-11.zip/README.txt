Habit Tracker export
User: Avinash <avinashkumar123jsr@gmail.com>, time zone Asia/Kolkata
Exported: 2026-11-11T17:57:01.484998Z

Dates are your local dates; *_at timestamps are UTC.
Weekday numbers: 0 = Monday ... 6 = Sunday (lists are separated by ';').
